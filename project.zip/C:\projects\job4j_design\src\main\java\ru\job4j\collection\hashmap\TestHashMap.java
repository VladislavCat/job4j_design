package ru.job4j.collection.hashmap;

import java.util.HashMap;
import java.util.Map;

public class TestHashMap {
    public static void main(String[] args) {
        int a = 1224530239;
        System.out.println(a >> 2);
        int b = a >>> 16;
        System.out.println(a ^ b);
    }
}
